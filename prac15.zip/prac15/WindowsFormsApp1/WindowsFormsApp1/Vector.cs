﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    internal class Vector
    {
        private double x;
        private double y;
        private double z;

        public Vector(double x, double y, double z)
        {
            this.x = x;
            this.y = y;
            this.z = z;
        }

        public Vector Add(Vector other)
        {
            return new Vector(x + other.x, y + other.y, z + other.z);
        }

        public Vector Subtract(Vector other)
        {
            return new Vector(x - other.x, y - other.y, z - other.z);
        }

        public double DotProduct(Vector other)
        {
            return x * other.x + y * other.y + z * other.z;
        }

        public double Magnitude()
        {
            return Math.Sqrt(x * x + y * y + z * z);
        }

        public double Cos(Vector other)
        {
            double dotProduct = DotProduct(other);
            double magnitudeProduct = Magnitude() * other.Magnitude();
            return dotProduct / magnitudeProduct;
        }

        public override string ToString()
        {
            return $"({x}, {y}, {z})";
        }
    }
}
